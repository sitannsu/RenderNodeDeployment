const mongoose = require('mongoose');

const patientQuerySchema = new mongoose.Schema({
  patient: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Patient',
    required: true
  },
  doctor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  symptoms: {
    type: String
  },
  duration: {
    type: String,
   
  },
  previousTreatments: {
    type: String
  },
  attachments: [{
    url: String,
    description: String
  }], // optional, not required
  preferredTime: {
    type: String
  },
  status: {
    type: String,
    enum: ['pending', 'accepted', 'rejected', 'completed'],
    default: 'pending'
  },
  doctorResponse: {
    type: String
  },
  doctorResponseTime: {
    type: Date
  },
  consultationType: {
    type: String,
    // enum: ['online', 'in-person'],
    required: true
  },
  appointmentTime: {
    type: Date
  },
  additionalNotes: {
    type: String
  },
  subject: {
    type: String
  },
  urgency: {
    type: String,
    enum: ['low', 'medium', 'high'],
    default: 'medium'
  },
  patientContactNo: {
    type: String
  }
}, {
  timestamps: true
});

// Indexes for faster queries
patientQuerySchema.index({ patient: 1, status: 1 });
patientQuerySchema.index({ doctor: 1, status: 1 });
patientQuerySchema.index({ status: 1, createdAt: -1 });

const PatientQuery = mongoose.model('PatientQuery', patientQuerySchema);
module.exports = PatientQuery;
