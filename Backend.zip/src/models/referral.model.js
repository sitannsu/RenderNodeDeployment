const mongoose = require('mongoose');

const referralSchema = new mongoose.Schema({
  patientName: {
    type: String,
    required: [true, 'Patient name is required'],
    trim: true
  },
  patientAge: {
    type: Number,
    required: [true, 'Patient age is required']
  },
  patientGender: {
    type: String,
    required: [true, 'Patient gender is required'],
    enum: ['male', 'female', 'other']
  },
  diagnosis: {
    type: String,
    required: [true, 'Diagnosis is required']
  },
  reason: {
    type: String,
    required: [true, 'Reason for referral is required']
  },
  urgency: {
    type: String,
    enum: ['low', 'medium', 'high', 'emergency'],
    default: 'medium'
  },
  referringDoctor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  referredToDoctor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'accepted', 'rejected', 'completed'],
    default: 'pending'
  },
  medicalHistory: {
    type: String
  },
  currentMedications: [{
    name: String,
    dosage: String,
    frequency: String
  }],
  attachments: [{
    type: String // URLs to uploaded files
  }],
  notes: {
    type: String
  }
}, {
  timestamps: true
});

// Index for faster queries
referralSchema.index({ referringDoctor: 1, status: 1 });
referralSchema.index({ referredToDoctor: 1, status: 1 });

const Referral = mongoose.model('Referral', referralSchema);
module.exports = Referral;
