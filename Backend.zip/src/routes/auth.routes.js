const express = require('express');
const jwt = require('jsonwebtoken');
const User = require('../models/user.model');
const nmcService = require('../services/nmc.service');
const router = express.Router();

// Middleware to protect routes
const auth = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: 'Authentication required' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }

    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
};

// Register new doctor
router.post('/register', async (req, res) => {
  try {
    const {
      fullName,
      email,
      password,
      specialization,
      hospitalName,
      phoneNumber,
      address,
      registrationNumber,
      yearsOfExperience
    } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    // Verify doctor with NMC
    console.log('Verifying doctor with NMC:', { fullName, registrationNumber });
    const nmcVerification = await nmcService.verifyDoctor(
      fullName,
      registrationNumber,
      new Date().getFullYear() // Current year as default, can be made configurable
    );

    if (!nmcVerification.isValid) {
      return res.status(400).json({
        message: 'Invalid doctor registration. Please check your registration number and name.',
        details: nmcVerification.message
      });
    }

    console.log('NMC verification successful:', nmcVerification.data);

    // Create new user
    const user = new User({
      fullName,
      email,
      password,
      specialization,
      hospitalName,
      phoneNumber,
      address,
      registrationNumber,
      yearsOfExperience
    });

    await user.save();

    // Generate JWT token
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: '30d'
    });

    res.status(201).json({
      token,
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        specialization: user.specialization,
        hospitalName: user.hospitalName
      }
    });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user and include password for comparison
    const user = await User.findOne({ email }).select('+password');
    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Check password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Generate JWT token
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: '30d'
    });

    res.json({
      token,
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        specialization: user.specialization,
        hospitalName: user.hospitalName
      }
    });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get current user profile
router.get('/profile', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    res.json(user);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Update user profile
router.patch('/profile', auth, async (req, res) => {
  const updates = Object.keys(req.body);
  const allowedUpdates = [
    'fullName',
    'specialization',
    'hospitalName',
    'phoneNumber',
    'address',
    'profileImage'
  ];

  const isValidOperation = updates.every(update => allowedUpdates.includes(update));
  if (!isValidOperation) {
    return res.status(400).json({ message: 'Invalid updates' });
  }

  try {
    updates.forEach(update => req.user[update] = req.body[update]);
    await req.user.save();
    res.json(req.user);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Validate doctor registration number
router.post('/validate-registration', async (req, res) => {
  try {
    const { registrationNumber, fullName } = req.body;

    if (!registrationNumber) {
      return res.status(400).json({
        isValid: false,
        message: 'Registration number is required'
      });
    }

    // If fullName is not provided, only check if format is valid
    if (!fullName) {
      // Basic format validation (can be customized)
      const isValidFormat = /^[A-Z]{2,5}\d{4,8}$/i.test(registrationNumber);
      return res.json({
        isValid: isValidFormat,
        message: isValidFormat ? 'Valid format' : 'Invalid registration number format'
      });
    }

    // If both registration number and name are provided, verify with NMC
    const nmcVerification = await nmcService.verifyDoctor(
      fullName,
      registrationNumber,
      new Date().getFullYear()
    );

    res.json({
      isValid: nmcVerification.isValid,
      message: nmcVerification.message,
      data: nmcVerification.data
    });

  } catch (error) {
    console.error('Registration validation error:', error);
    res.status(500).json({
      isValid: false,
      message: 'Failed to validate registration. Please try again.'
    });
  }
});

module.exports = router;
