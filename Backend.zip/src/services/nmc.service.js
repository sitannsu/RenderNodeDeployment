const axios = require('axios');

class NMCService {
  constructor() {
    this.baseUrl = 'https://www.nmc.org.in/MCIRest/open';
  }

  async verifyDoctor(name, registrationNo, year) {
    try {
      const response = await axios.get(`${this.baseUrl}/getPaginatedData`, {
        params: {
          service: 'getPaginatedDoctor',
          start: 0,
          length: 10,
          name: name,
          registrationNo: registrationNo,
          year: year
        }
      });

      // If data is found, it means the doctor is registered with NMC
      if (response.data && response.data.data && response.data.data.length > 0) {
        // Find exact match
        const exactMatch = response.data.data.find(doctor => 
          doctor.registrationNo.toLowerCase() === registrationNo.toLowerCase() &&
          doctor.name.toLowerCase().includes(name.toLowerCase())
        );

        if (exactMatch) {
          return {
            isValid: true,
            data: exactMatch
          };
        }
      }

      return {
        isValid: false,
        message: 'Doctor not found in NMC records'
      };

    } catch (error) {
      console.error('NMC API Error:', error);
      return {
        isValid: false,
        message: 'Failed to verify with NMC. Please try again later.'
      };
    }
  }
}

module.exports = new NMCService();
