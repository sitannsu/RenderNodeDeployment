# Kappu Doctor App Backend

Backend API server for the Kappu Doctor App, built with Node.js, Express, and MongoDB.

## Setup

1. Install dependencies:
```bash
npm install
```

2. Create a `.env` file in the root directory with the following variables:
```
MONGODB_URI=your_mongodb_connection_string
PORT=5000
JWT_SECRET=your_jwt_secret
```

3. Start the development server:
```bash
npm run dev
```

## API Endpoints

### Authentication

- **POST /api/auth/register**
  - Register a new doctor
  - Body: `{ fullName, email, password, specialization, hospitalName, phoneNumber, address, registrationNumber, yearsOfExperience }`

- **POST /api/auth/login**
  - Login with email and password
  - Body: `{ email, password }`

- **GET /api/auth/profile**
  - Get current user profile
  - Requires: Authentication token

- **PATCH /api/auth/profile**
  - Update user profile
  - Requires: Authentication token
  - Body: `{ fullName, specialization, hospitalName, phoneNumber, address, profileImage }`

### Doctors

- **GET /api/doctors**
  - Get all doctors
  - Requires: Authentication token

- **GET /api/doctors/:id**
  - Get doctor by ID
  - Requires: Authentication token

- **GET /api/doctors/search**
  - Search doctors by name or specialization
  - Query params: `query`, `specialization`
  - Requires: Authentication token

- **GET /api/doctors/stats/:id**
  - Get doctor statistics
  - Requires: Authentication token

### Referrals

- **POST /api/referrals**
  - Create a new referral
  - Requires: Authentication token
  - Body: `{ patientName, patientAge, patientGender, diagnosis, reason, urgency, referredToDoctor, medicalHistory, currentMedications, attachments, notes }`

- **GET /api/referrals**
  - Get all referrals for a doctor
  - Query params: `status`, `type` (sent/received)
  - Requires: Authentication token

- **GET /api/referrals/:id**
  - Get specific referral
  - Requires: Authentication token

- **PATCH /api/referrals/:id/status**
  - Update referral status
  - Requires: Authentication token
  - Body: `{ status }`

- **PATCH /api/referrals/:id/notes**
  - Add notes to referral
  - Requires: Authentication token
  - Body: `{ notes }`

- **GET /api/referrals/stats/summary**
  - Get referral statistics
  - Requires: Authentication token

### Messages

- **POST /api/messages**
  - Send a new message
  - Requires: Authentication token
  - Body: `{ recipient, content, referral?, attachments? }`

- **GET /api/messages**
  - Get all messages
  - Query params: `type` (sent/received), `recipient`
  - Requires: Authentication token

- **GET /api/messages/conversation/:doctorId**
  - Get conversation with specific doctor
  - Requires: Authentication token

- **PATCH /api/messages/:id/read**
  - Mark message as read
  - Requires: Authentication token

- **GET /api/messages/unread/count**
  - Get unread message count
  - Requires: Authentication token

- **DELETE /api/messages/:id**
  - Delete a message
  - Requires: Authentication token

## Authentication

All protected routes require a Bearer token in the Authorization header:
```
Authorization: Bearer your_jwt_token
```

## Error Handling

The API returns appropriate HTTP status codes and error messages in the following format:
```json
{
  "message": "Error description"
}
```

## Models

### User
- fullName
- email
- password (hashed)
- specialization
- hospitalName
- phoneNumber
- address
- registrationNumber
- yearsOfExperience
- profileImage
- isVerified
- role

### Referral
- patientName
- patientAge
- patientGender
- diagnosis
- reason
- urgency
- referringDoctor
- referredToDoctor
- status
- medicalHistory
- currentMedications
- attachments
- notes

### Message
- sender
- recipient
- content
- referral (optional)
- attachments
- read
- readAt
